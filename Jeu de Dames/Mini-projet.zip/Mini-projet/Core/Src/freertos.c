/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"
#include "stdio.h"
#include <stdlib.h>
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
#include "dac.h"
#include "dma2d.h"
#include "i2c.h"
#include "ltdc.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fmc.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define displayChange    0x01
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
static TaskHandle_t xHandlingTask;
extern int damier[10][10];
extern uint8_t joueur;
EventGroupHandle_t Event_selection;
uint8_t afficher_new = 1;

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId AffichageHandle;
osThreadId SelectionHandle;
osThreadId Affichage_victoHandle;
osMessageQId mAffichageHandle;
osSemaphoreId mutex_damierHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
uint8_t new_capture(int colonne_0, int ligne_0, uint8_t j);
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void Display_jeu(void const * argument);
void Select_pion(void const * argument);
void victoire(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of mutex_damier */
  osSemaphoreDef(mutex_damier);
  mutex_damierHandle = osSemaphoreCreate(osSemaphore(mutex_damier), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of mAffichage */
  osMessageQDef(mAffichage, 2, uint16_t);
  mAffichageHandle = osMessageCreate(osMessageQ(mAffichage), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of Affichage */
  osThreadDef(Affichage, Display_jeu, osPriorityNormal, 0, 1024);
  AffichageHandle = osThreadCreate(osThread(Affichage), NULL);

  /* definition and creation of Selection */
  osThreadDef(Selection, Select_pion, osPriorityNormal, 0, 128);
  SelectionHandle = osThreadCreate(osThread(Selection), NULL);

  /* definition and creation of Affichage_victo */
  osThreadDef(Affichage_victo, victoire, osPriorityIdle, 0, 1024);
  Affichage_victoHandle = osThreadCreate(osThread(Affichage_victo), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1000);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_Display_jeu */
/**
* @brief Function implementing the Affichage thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Display_jeu */
void Display_jeu(void const * argument)
{
  /* USER CODE BEGIN Display_jeu */
  uint32_t couleur, couleur_pièce;
  uint16_t x, y;
  uint32_t a;
  uint16_t b;
//  EventBits_t uxBits;

//  xEventGroupSetBits(Event_selection, 0b11);
  /* Infinite loop */
  for(;;)
  {
//    uxBits = xEventGroupWaitBits(Event_selection,
//            0b11,
//            pdTRUE,   // Efface le bit une fois pris en compte
//            pdFALSE,  // Pas besoin d’attendre la combinaison de bits
//            portMAX_DELAY);

    for (x = 0; x < 10; x++){
      for (y = 0; y < 10; y++){
//        if (uxBits == 0b11) {
//        if (afficher_new == 1){
          if ( xSemaphoreTake(mutex_damierHandle, (TickType_t)10 ) == pdTRUE )
          {
            if (damier[x][y] != 0) {
              // couleur du pion ou de la dame
              if (damier[x][y] == 1 || damier[x][y] == 3) {
                couleur_pièce = LCD_COLOR_BROWN;
              } else {
                couleur_pièce = LCD_COLOR_WHITE;
              }
              BSP_LCD_SetTextColor(couleur_pièce);
              BSP_LCD_SelectLayer(1);

              // dessin différent pour la dame
              if (damier[x][y] == 3 || damier[x][y] == 4) {
                BSP_LCD_FillCircle(123 + 26 * x, 19 + 26 * y, 12);
                BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
                BSP_LCD_FillCircle(123 + 26 * x, 19 + 26 * y, 6);
              } else {
                BSP_LCD_FillCircle(123 + 26 * x, 19 + 26 * y, 10);
              }
            }
            else if (damier[x][y] == 0) {
              BSP_LCD_SelectLayer(1);
              couleur = ((x + y) % 2 == 0) ? LCD_COLOR_WHITE : LCD_COLOR_DARKGRAY;
              BSP_LCD_SetTextColor(couleur);
              BSP_LCD_FillRect(110 + 26 * x, 6 + 26 * y, 26, 26);
            }
            xSemaphoreGive(mutex_damierHandle);
          }
//          afficher_new = 0;
//        }
      }
    }
    osDelay(10);
    xQueueReceive(mAffichageHandle,&b,portMAX_DELAY);
  }
  /* USER CODE END Display_jeu */
}

/* USER CODE BEGIN Header_Select_pion */
/**
* @brief Function implementing the Selection thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Select_pion */
void Select_pion(void const * argument)
{
  /* USER CODE BEGIN Select_pion */
  uint16_t x, y;
  uint16_t ligne, colonne;
  uint16_t ligne_sélectionnée = 0, colonne_sélectionnée = 0;
  uint8_t pièce_sélectionnée = 0, libre, p, cible, v;
  uint16_t colonne_mangée, ligne_mangée;
  BSP_TS_Init(BSP_LCD_GetXSize(), BSP_LCD_GetYSize());
  static TS_StateTypeDef TS_State;
  int sx, sy, count_adv, mx, my, dx, dy ,adx, ady;
  uint16_t a = 1;

  for (;;)
  {
    BSP_TS_GetState(&TS_State);
    if (TS_State.touchDetected) {
      x = TS_State.touchX[0];
      y = TS_State.touchY[0];

      // Vérification si la touche est sur le damier
      if ((x >= 110 && x <= 370) && (y >= 6 && y <= 266)) {
        colonne = (x - 110) / 26;
        ligne   = (y - 6)   / 26;

        if (xSemaphoreTake(mutex_damierHandle, (TickType_t)10) == pdTRUE)
        {
          // Sélection du pion ou de la dame
          if (!pièce_sélectionnée && ((damier[colonne][ligne] == 1 || damier[colonne][ligne] == 3) && joueur == 1
                                   || (damier[colonne][ligne] == 2 || damier[colonne][ligne] == 4) && joueur == 2))
          {
            colonne_sélectionnée = colonne;
            ligne_sélectionnée   = ligne;
            pièce_sélectionnée   = 1;
            BSP_LCD_SetTextColor(LCD_COLOR_TRANSPARENT);
            BSP_LCD_SelectLayer(1);
            BSP_LCD_FillCircle(123 + 26 * colonne_sélectionnée,
                               19 + 26 * ligne_sélectionnée, 10);
          }
          else if (pièce_sélectionnée)
          {
            p = damier[colonne_sélectionnée][ligne_sélectionnée];
            cible = damier[colonne][ligne];
            dx = colonne - colonne_sélectionnée;
            dy = ligne   - ligne_sélectionnée;
            adx = abs(dx);
            ady = abs(dy);

            // Déplacement simple pour pion
            if ((p == 1 || p == 2) && cible == 0 && adx == 1
                && ((dy == 1 && p == 1) || (dy == -1 && p == 2)))
            {
              damier[colonne][ligne] = p;
              damier[colonne_sélectionnée][ligne_sélectionnée] = 0;
              // Promotion en dame
              if (p == 1 && ligne == 9) damier[colonne][ligne] = 3;
              else if (p == 2 && ligne == 0) damier[colonne][ligne] = 4;
              joueur = (joueur == 1) ? 2 : 1;
//            afficher_new = 1;
              xQueueSend( mAffichageHandle, &a, portMAX_DELAY);
            }
            // Déplacement dame : libre sur diagonale
            else if ((p == 3 || p == 4) && cible == 0 && adx == ady && adx > 0)
            {
              sx = dx / adx;
              sy = dy / ady;
              libre = 1;
              for (int i = 1; i < adx; i++) {
                if (damier[colonne_sélectionnée + i*sx][ligne_sélectionnée + i*sy] != 0) {
                  libre = 0;
                }
              }
              if (libre) {
                damier[colonne][ligne] = p;
                damier[colonne_sélectionnée][ligne_sélectionnée] = 0;
                joueur = (joueur == 1) ? 2 : 1;
//                afficher_new = 1
                xQueueSend( mAffichageHandle, &a, portMAX_DELAY);
              }
            }
            // Capture pion
            else if ((p == 1 || p == 2) && cible == 0 && adx == 2 && ady == 2)
            {
              colonne_mangée = (colonne + colonne_sélectionnée) / 2;
              ligne_mangée   = (ligne   + ligne_sélectionnée)   / 2;
              if (damier[colonne_mangée][ligne_mangée] == ((p == 1) ? 2 : 1))
              {
                damier[colonne][ligne] = p;
                damier[colonne_sélectionnée][ligne_sélectionnée] = 0;
                damier[colonne_mangée][ligne_mangée] = 0;
                // Promotion
                if (p == 1 && ligne == 9) damier[colonne][ligne] = 3;
                else if (p == 2 && ligne == 0) damier[colonne][ligne] = 4;
                if (!new_capture(colonne, ligne, joueur)){
                  joueur = (joueur == 1) ? 2 : 1;
//                afficher_new = 1
                  xQueueSend( mAffichageHandle, &a, portMAX_DELAY);
                  xQueueSend( mAffichageHandle, &a, portMAX_DELAY);
                }
              }
            }
            // Capture dame : un seul adversaire sur diagonale
            else if ((p == 3 || p == 4) && adx == ady && adx >= 2)
            {
              sx = dx / adx;
              sy = dy / ady;
              count_adv = 0;
              mx = 0;
              my = 0;
              for (int i = 1; i < adx; i++) {
                v = damier[colonne_sélectionnée + i*sx]
                            [ligne_sélectionnée + i*sy];
                if (v != 0) {
                  if ((p == 3 && (v == 2 || v == 4)) ||
                      (p == 4 && (v == 1 || v == 3)))
                  {
                    count_adv++;
                    mx = colonne_sélectionnée + i*sx;
                    my = ligne_sélectionnée + i*sy;
                  } else {
                    count_adv = 2;
                  }
                }
              }
              if (count_adv == 1 && cible == 0) {
                damier[colonne][ligne] = p;
                damier[colonne_sélectionnée][ligne_sélectionnée] = 0;
                damier[mx][my] = 0;
                if (!new_capture(colonne, ligne, joueur)){
                  joueur = (joueur == 1) ? 2 : 1;
//                afficher_new = 1
                  xQueueSend( mAffichageHandle, &a, portMAX_DELAY);
                }
              }
            }

            pièce_sélectionnée = 0;
          }

          xSemaphoreGive(mutex_damierHandle);
        }
      }
    }

    osDelay(10);
  }
  /* USER CODE END Select_pion */
}

/* USER CODE BEGIN Header_victoire */
/**
* @brief Function implementing the Affichage_victo thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_victoire */
void victoire(void const * argument)
{
  /* USER CODE BEGIN victoire */
  uint8_t count1, count2;
  uint16_t x, y;
  uint16_t ySize = BSP_LCD_GetYSize();
  Point cup1[6]  = {{200,136}, {200,100}, {160,64}, {320,64}, {280,100}, {280,136}};
  Point cup2[4]  = {{215,172}, {225,136}, {255,136}, {265,172}};
  Point hans1[8] = {{200,100},{180,90},{190,144},{200,135},{200,140},{170,126},{185,95},{200,95}};
  Point hans2[8] = {{280,100},{300,90},{290,144},{280,135},{280,140},{310,126},{295,95},{280,95}};

  /* Infinite loop */
  for(;;)
  {
    count1 = count2 = 0;
    for(x = 0; x < 10; x++) {
      for(y = 0; y < 10; y++) {
        if (damier[x][y] == 1 || damier[x][y] == 3) count1++;
        if (damier[x][y] == 2 || damier[x][y] == 4) count2++;
      }
    }

    if (count1 == 0 || count2 == 0) {
      if( xSemaphoreTake(mutex_damierHandle, (TickType_t)10 ) == pdTRUE )
      {
        BSP_LCD_SelectLayer(0); BSP_LCD_Clear(0);
        BSP_LCD_SelectLayer(1); BSP_LCD_Clear(0);
        BSP_LCD_SetFont(&Font24);

        BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
        BSP_LCD_FillPolygon(cup1, 6);
        BSP_LCD_FillPolygon(hans1, 8);
        BSP_LCD_FillPolygon(hans2, 8);
        BSP_LCD_FillPolygon(cup2, 4);

        if (count1 == 0) {
          BSP_LCD_DisplayStringAt(0, ySize/2+50, (uint8_t*)"Joueur 2 GAGNE!", CENTER_MODE);
        }
        else {
          BSP_LCD_DisplayStringAt(0, ySize/2+50, (uint8_t*)"Joueur 1 GAGNE!", CENTER_MODE);
        }
      }
    }
    osDelay(500);
  }
  /* USER CODE END victoire */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

